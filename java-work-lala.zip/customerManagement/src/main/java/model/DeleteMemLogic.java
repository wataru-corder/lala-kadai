package model;

import dao.MemberDAO;

public class DeleteMemLogic {
	public boolean execute(Member member) {
		MemberDAO dao = new MemberDAO();
		
		System.out.println(member.getId());
		System.out.println(member.getName());
		return  dao.remove(member.getId());
	}
}
