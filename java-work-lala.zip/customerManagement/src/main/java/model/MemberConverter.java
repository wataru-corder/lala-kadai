package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class MemberConverter {
    public Member execute(MemberForm memberForm) {
        LocalDate birthday = null;
        String birthdayStr = memberForm.getBirthday();

        if (birthdayStr != null && !birthdayStr.isEmpty()) {
            try {           
            	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                birthday = LocalDate.parse(birthdayStr,formatter);
            } catch (DateTimeParseException e) {
                e.printStackTrace(); 
            }
        }

        Member member =  new Member(
            memberForm.getName(),
            memberForm.getAddress(),
            birthday,
            memberForm.getTelephone(),
            memberForm.getGender()
        );
        return member;
    }
}
