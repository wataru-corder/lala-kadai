package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.DeleteMemLogic;
import model.Member;
import model.MemberConverter;
import model.MemberForm;
import model.RegisterMemLogic;
import servlet.util.MakeMemByParam;

@WebServlet(urlPatterns = {"/createDone","/deleteDone"})
public class DoneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		

		MakeMemByParam makeMemByParam = new MakeMemByParam();
		MemberForm memberForm = makeMemByParam.execute(request);
		
		MemberConverter converter = new MemberConverter();
		
		Member member = converter.execute(memberForm);
		
		
		String url = "WEB-INF/jsp/done.jsp";
		
		switch (path) {
		case "/createDone":
			RegisterMemLogic registerLogic = new RegisterMemLogic();
			registerLogic.execute(member); 
			request.setAttribute("message", "登録完了しました");
			break;
		case "/deleteDone":
		    Member member1 = new MakeMemByParam().executeMem(request); 
		    new DeleteMemLogic().execute(member1);
		    request.setAttribute("message", "削除しました");
		    break;
		}
		
		request.getRequestDispatcher(url).forward(request, response);
	}

}
//登録しましたという画面を表示する