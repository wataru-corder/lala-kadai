package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Member;
import model.MemberConverter;
import model.MemberForm;
import model.RegisterMemLogic;
import servlet.util.MakeMemByParam;

@WebServlet(urlPatterns = {"/createDone","/deleteDone"})
public class DoneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		

		MakeMemByParam makeMemByParam = new MakeMemByParam();
		MemberForm memberForm = makeMemByParam.execute(request);
		
		MemberConverter converter = new MemberConverter();
		Member member = converter.execute(memberForm);
		
		String url = null;
		switch (path) {
		case "/createDone":
			RegisterMemLogic logic = new RegisterMemLogic();
			logic.execute(member);
			url = "WEB-INF/jsp/done.jsp";
			break;
		}
		
		request.getRequestDispatcher(url).forward(request, response);
	}

}
//登録しましたという画面を表示する