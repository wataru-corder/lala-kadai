package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Member;
import model.MemberConverter;
import model.MemberForm;
import servlet.util.MakeMemByParam;
import servlet.util.Validator;

@WebServlet(urlPatterns = {"/createConfirm","/updateConfirm","/deleteConfirm"})
public class ConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	MakeMemByParam makeMemByParam = new MakeMemByParam();
	
	MemberForm memberForm = makeMemByParam.execute(request);
	
	MemberConverter memberConverter = new MemberConverter();
	
	Member member = memberConverter.execute(memberForm);
	
	Member member2 = makeMemByParam.executeMem(request);
	
	Validator validator = new Validator();
	List<String> errorList = validator.check(memberForm, request);
	String url = null;
	String path = request.getServletPath();
	
	request.setAttribute("memberForm", memberForm);
	request.setAttribute("member", member2);
	
	request.setAttribute("errorList", errorList);
	
	switch (path) {
	case "/createConfirm": 
		request.setAttribute("nextURL", "createDone");
		break;
	case "/updateConfirm": 
		request.setAttribute("nextURL", "updateDone");
		break;
	case "/deleteConfirm":
		request.setAttribute("nextURL", "deleteDone");
	}
	
	
	if(errorList.size() > 0) {
		url = "WEB-INF/jsp/input.jsp";
	}else {
		url = "WEB-INF/jsp/confirm.jsp";
	}
	
	request.getRequestDispatcher(url).forward(request, response);
	
	}

}
