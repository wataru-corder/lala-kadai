package servlet.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import model.MemberForm;

public class Validator {
	
	public List<String> check(MemberForm memberForm,HttpServletRequest request){
		String path = request.getServletPath();
		switch (path) {
		case "/createConfirm":
			return checkCreate(memberForm);
			
//		case "/updateConfirm":
//			return checkUpdate(memberForm);
		default: 
			return new ArrayList<>();
		}
	}
	
	
	public List<String> checkCreate(MemberForm memberForm) {
		List<String> errorList = new ArrayList<>();
		
		isString(memberForm,errorList);
		
		checkTelephone(memberForm,errorList);
		
		if(!isDate(memberForm.getBirthday())) {
			errorList.add("日付が不正です");
		}
		return errorList;
		
	}
	
	public List<String> isString(MemberForm memberForm ,List<String> errorList) {
		if(memberForm.getName() == null || memberForm.getName().length() == 0) {
			errorList.add("名前が未入力です");
		}
		if(memberForm.getAddress() == null || memberForm.getAddress().length() == 0) {
			errorList.add("住所が未入力です");
		}
		return errorList;
	}
	
	public boolean isDate(String dateTxt) {
		
		if(dateTxt == null ||  dateTxt.trim().isEmpty()) return false;
		String pattern = "yyyy/MM/dd";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		try {
			LocalDate.parse(dateTxt,formatter);
		}catch (DateTimeParseException e) {
			return false;
		}
		return true;
	}
	
	public List<String> checkTelephone(MemberForm memberForm, List<String> errorList) {
		
		if(memberForm.getTelephone() == null || memberForm.getTelephone().length() == 0) {
			errorList.add("電話番号が未入力です");
		}else if(!memberForm.getTelephone().matches("^[0-9]+$")) {
			errorList.add("半角数字で番号を入力してください");
		}
		
		return errorList;
	}
	
	

}
