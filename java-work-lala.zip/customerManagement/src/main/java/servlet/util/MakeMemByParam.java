package servlet.util;

import jakarta.servlet.http.HttpServletRequest;

import model.MemberForm;

public class MakeMemByParam {
	public MemberForm execute(HttpServletRequest request) {
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		String gender = request.getParameter("gender");
		String telephone = request.getParameter("telephone");
		String address = request.getParameter("address");
		
		
		
		MemberForm memberForm  = new MemberForm(name, address, birthday, telephone, gender);
		
		return memberForm;
	}
}
