package servlet.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import jakarta.servlet.http.HttpServletRequest;

import model.Member;
import model.MemberForm;

public class MakeMemByParam {
	public MemberForm execute(HttpServletRequest request) {
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		String gender = request.getParameter("gender");
		String telephone = request.getParameter("telephone");
		String address = request.getParameter("address");
		
		MemberForm memberForm  = new MemberForm(name, address, birthday, telephone, gender);
		
		return memberForm;
	}
	
	public Member executeMem(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		
		String birthdayStr = request.getParameter("birthday");
		LocalDate birthday = null;
		 if (birthdayStr != null && !birthdayStr.isEmpty()) {
	            try {           
	            	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	                birthday = LocalDate.parse(birthdayStr,formatter);
	            } catch (DateTimeParseException e) {
	                e.printStackTrace(); 
	            }
	       }
		
		String gender = request.getParameter("gender");
		String telephone = request.getParameter("telephone");
		String address = request.getParameter("address");
		Member member  = new Member(id,name, address, telephone, birthday, gender);
		
		return member;
	}
}
